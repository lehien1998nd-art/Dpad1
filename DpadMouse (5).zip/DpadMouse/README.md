# Dpad Mouse – con trỏ chuột bằng D-pad cho Android 5.1

App dùng **Accessibility Service** (không cần root cho app thường) để:
- chặn phím D-pad, vẽ con trỏ lên trên mọi màn hình,
- click vào nút/ô nằm dưới con trỏ.

## Build APK
Cần Android Studio (hoặc Android SDK + Gradle).

**Cách 1 – Android Studio:** File > Open > chọn thư mục `DpadMouse` > chờ Gradle sync >
Build > Build Bundle(s)/APK(s) > Build APK(s).
(Nếu Studio đề nghị nâng cấp Android Gradle Plugin thì cứ đồng ý.)

**Cách 2 – dòng lệnh:**
```
export ANDROID_HOME=/đường/dẫn/Android/Sdk
gradle assembleDebug
```
APK ra tại `app/build/outputs/apk/debug/app-debug.apk` (đã ký bằng debug key, cài được ngay).

## Cài lên máy J36 Ultra
Chép APK vào máy rồi mở bằng trình quản lý file (bật "Nguồn không xác định"), hoặc:
```
adb install app-debug.apk
```

## Bật dịch vụ
Cài đặt > Trợ năng > **Dpad Mouse** > Bật.
Nếu ROM của máy không có mục Trợ năng, bật bằng adb:
```
adb shell settings put secure enabled_accessibility_services com.dpadmouse.app/.CursorService
adb shell settings put secure accessibility_enabled 1
```

## Phím điều khiển
| Phím | Chức năng |
|---|---|
| SELECT (đổi được trong app) | Bật/tắt con trỏ |
| D-pad | Di chuyển (giữ lâu = nhanh dần) |
| D-pad giữa / A | Click |
| X | Click giữ |
| L1 / R1 | Cuộn lên / xuống |

## Giới hạn cần biết
- Click ở chế độ thường dùng Accessibility (Android 5.1 chưa có `dispatchGesture`), nên chỉ bấm được
  vào control mà app khai báo (nút, danh sách, ô nhập...). **Game, emulator, WebView/canvas** thường không
  có node để bấm → tích "Dùng quyền root" trong app (cần máy đã root, dùng lệnh `su -c input tap`).
- Accessibility Service trên Android 5.1 **không nhận được trục analog của joystick**, chỉ nhận phím.
  Nếu joystick của máy được ROM map thành phím D-pad thì dùng bình thường; nếu nó chỉ gửi trục analog
  thì cần cách đọc khác (đọc `/dev/input` bằng root).

## Build bằng điện thoại (GitHub Actions)
1. Tạo repo mới trên github.com (trình duyệt điện thoại, bật "Desktop site" cho dễ).
2. Upload toàn bộ file của project lên repo (Add file > Upload files).
   Thư mục ẩn `.github` hay bị bỏ sót khi upload: hãy tạo tay bằng Add file > Create new file,
   gõ tên `.github/workflows/build.yml` rồi dán nội dung file `build.yml` trong zip.
3. Vào tab **Actions**, chờ job "Build APK" chạy xong (3–6 phút). Nếu không tự chạy: chọn workflow > Run workflow.
4. Mở lần chạy đã xong, kéo xuống **Artifacts**, tải `DpadMouse-apk` (file zip chứa app-debug.apk), giải nén rồi cài.
