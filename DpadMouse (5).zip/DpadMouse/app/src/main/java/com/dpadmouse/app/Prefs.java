package com.dpadmouse.app;

import android.view.KeyEvent;

final class Prefs {
    static final String NAME = "dpadmouse";

    static final String KEY_TOGGLE = "toggle_key";
    static final String KEY_CLICK = "click_key";
    // Gán phím vật lý -> hành động hệ thống (-1 = chưa gán)
    static final String KEY_HOME = "home_key";
    static final String KEY_BACK = "back_key";
    static final String KEY_RECENTS = "recents_key";
    // Vuốt cuộn feed (TikTok...): lên = video kế tiếp, xuống = video trước
    static final String KEY_SWIPE_UP = "swipe_up_key";
    static final String KEY_SWIPE_DOWN = "swipe_down_key";
    static final int UNSET = -1;

    static final String SPEED = "speed";
    static final String ROOT = "use_root";
    static final String JOY = "use_joystick";

    // Mặc định: SELECT bật/tắt con trỏ, D-pad giữa (hoặc nút A) = click
    static final int DEF_TOGGLE = KeyEvent.KEYCODE_BUTTON_SELECT;
    static final int DEF_CLICK = KeyEvent.KEYCODE_DPAD_CENTER;
    static final int DEF_SPEED = 12;

    private Prefs() {}
}
