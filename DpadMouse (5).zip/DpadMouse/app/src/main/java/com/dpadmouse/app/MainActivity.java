package com.dpadmouse.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {

    private SharedPreferences prefs;
    private LinearLayout root;
    private TextView status, speedLabel;
    private Button btnToggleKey, btnClickKey, btnHomeKey, btnBackKey, btnRecentsKey;
    private Button btnSwipeUpKey, btnSwipeDownKey;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(16));
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);

        status = new TextView(this);
        status.setTextSize(18);
        root.addView(status);

        Button btnAcc = new Button(this);
        btnAcc.setText("Mở cài đặt Trợ năng (bật Dpad Mouse)");
        btnAcc.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
        root.addView(btnAcc);

        speedLabel = new TextView(this);
        speedLabel.setPadding(0, dp(16), 0, 0);
        root.addView(speedLabel);

        SeekBar seek = new SeekBar(this);
        seek.setMax(39); // tốc độ 1..40
        seek.setProgress(prefs.getInt(Prefs.SPEED, Prefs.DEF_SPEED) - 1);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                prefs.edit().putInt(Prefs.SPEED, p + 1).apply();
                refresh();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        root.addView(seek);

        TextView t1 = new TextView(this);
        t1.setText("Phím cho con trỏ");
        t1.setTextSize(16);
        t1.setPadding(0, dp(16), 0, 0);
        root.addView(t1);
        btnToggleKey = addKeyButton(Prefs.KEY_TOGGLE, "Gán phím BẬT/TẮT con trỏ");
        btnClickKey = addKeyButton(Prefs.KEY_CLICK, "Gán phím CLICK");

        TextView t2 = new TextView(this);
        t2.setText("Phím chức năng hệ thống (thay Button Mapper)");
        t2.setTextSize(16);
        t2.setPadding(0, dp(16), 0, 0);
        root.addView(t2);
        btnHomeKey = addKeyButton(Prefs.KEY_HOME, "Gán phím HOME");
        btnBackKey = addKeyButton(Prefs.KEY_BACK, "Gán phím BACK");
        btnRecentsKey = addKeyButton(Prefs.KEY_RECENTS, "Gán phím ĐA NHIỆM (Recents)");

        TextView t3 = new TextView(this);
        t3.setText("Vuốt xem video (TikTok, Reels...) - không cần bật con trỏ");
        t3.setTextSize(16);
        t3.setPadding(0, dp(16), 0, 0);
        root.addView(t3);
        btnSwipeUpKey = addKeyButton(Prefs.KEY_SWIPE_UP, "Gán phím VUỐT LÊN (video kế tiếp)");
        btnSwipeDownKey = addKeyButton(Prefs.KEY_SWIPE_DOWN, "Gán phím VUỐT XUỐNG (video trước)");

        CheckBox rootBox = new CheckBox(this);
        rootBox.setText("Dùng quyền root để click (chạy được trong game)");
        rootBox.setChecked(prefs.getBoolean(Prefs.ROOT, false));
        rootBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean checked) {
                prefs.edit().putBoolean(Prefs.ROOT, checked).apply();
            }
        });
        root.addView(rootBox);

        CheckBox joyBox = new CheckBox(this);
        joyBox.setText("Dùng cần joystick analog điều khiển con trỏ "
                + "(khi con trỏ bật, nút B/Back = quay lại; bàn phím ảo không gõ được)");
        joyBox.setChecked(prefs.getBoolean(Prefs.JOY, false));
        joyBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean checked) {
                prefs.edit().putBoolean(Prefs.JOY, checked).apply();
            }
        });
        root.addView(joyBox);

        TextView help = new TextView(this);
        help.setPadding(0, dp(16), 0, 0);
        help.setText("Cách dùng:\n"
                + "• Bật dịch vụ trong Cài đặt > Trợ năng > Dpad Mouse.\n"
                + "• Nhấn phím BẬT/TẮT (mặc định SELECT) để hiện/ẩn con trỏ.\n"
                + "• D-pad: di chuyển (giữ lâu sẽ nhanh dần).\n"
                + "• D-pad giữa hoặc A: click. X: click giữ.\n"
                + "• L1 / R1: cuộn lên / xuống.\n"
                + "• Phím HOME/BACK/ĐA NHIỆM đã gán hoạt động cả khi con trỏ tắt.\n"
                + "• Trong hộp thoại gán phím, bấm \"Xóa gán\" để bỏ gán.");
        root.addView(help);
    }

    private Button addKeyButton(final String prefKey, final String title) {
        Button b = new Button(this);
        b.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                captureKey(prefKey, title);
            }
        });
        root.addView(b);
        return b;
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private String keyName(String prefKey, int def) {
        int code = prefs.getInt(prefKey, def);
        if (code < 0) return "chưa gán";
        return KeyEvent.keyCodeToString(code);
    }

    private void refresh() {
        boolean on = CursorService.instance != null;
        status.setText(on ? "Dịch vụ: ĐANG CHẠY" : "Dịch vụ: CHƯA BẬT");
        speedLabel.setText("Tốc độ con trỏ: " + prefs.getInt(Prefs.SPEED, Prefs.DEF_SPEED));
        btnToggleKey.setText("Bật/tắt con trỏ: " + keyName(Prefs.KEY_TOGGLE, Prefs.DEF_TOGGLE));
        btnClickKey.setText("Click: " + keyName(Prefs.KEY_CLICK, Prefs.DEF_CLICK));
        btnHomeKey.setText("Home: " + keyName(Prefs.KEY_HOME, Prefs.UNSET));
        btnBackKey.setText("Back: " + keyName(Prefs.KEY_BACK, Prefs.UNSET));
        btnRecentsKey.setText("Đa nhiệm: " + keyName(Prefs.KEY_RECENTS, Prefs.UNSET));
        btnSwipeUpKey.setText("Vuốt lên (video kế): " + keyName(Prefs.KEY_SWIPE_UP, Prefs.UNSET));
        btnSwipeDownKey.setText("Vuốt xuống (video trước): " + keyName(Prefs.KEY_SWIPE_DOWN, Prefs.UNSET));
    }

    private void captureKey(final String prefKey, String title) {
        CursorService.captureMode = true;
        AlertDialog.Builder bd = new AlertDialog.Builder(this);
        bd.setTitle(title);
        bd.setMessage("Hãy nhấn một phím trên tay cầm.\n(Nhấn Back để hủy)");
        bd.setNeutralButton("Xóa gán", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                prefs.edit().remove(prefKey).apply();
            }
        });
        bd.setOnKeyListener(new DialogInterface.OnKeyListener() {
            @Override
            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {
                    if (keyCode != KeyEvent.KEYCODE_BACK) {
                        prefs.edit().putInt(prefKey, keyCode).apply();
                    }
                    dialog.dismiss();
                }
                return true;
            }
        });
        bd.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                CursorService.captureMode = false;
                refresh();
            }
        });
        bd.show();
    }
}
