package com.dpadmouse.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Vẽ mũi tên con trỏ. Đỉnh mũi tên nằm tại (pad, pad) trong view. */
public class CursorView extends View {
    final int pad;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private boolean pressed = false;

    public CursorView(Context c) {
        super(c);
        float d = c.getResources().getDisplayMetrics().density;
        pad = (int) (2 * d);
        fill.setStyle(Paint.Style.FILL);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setColor(0xFF000000);
        stroke.setStrokeWidth(1.5f * d);
        stroke.setStrokeJoin(Paint.Join.ROUND);
    }

    /** Nháy màu đỏ ngắn khi click. */
    void flash() {
        pressed = true;
        invalidate();
        postDelayed(new Runnable() {
            @Override public void run() {
                pressed = false;
                invalidate();
            }
        }, 120);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float s = Math.min(getWidth(), getHeight()) - 2 * pad;
        canvas.save();
        canvas.translate(pad, pad);
        path.reset();
        path.moveTo(0, 0);
        path.lineTo(0, s * 0.85f);
        path.lineTo(s * 0.22f, s * 0.65f);
        path.lineTo(s * 0.38f, s * 1.00f);
        path.lineTo(s * 0.52f, s * 0.93f);
        path.lineTo(s * 0.36f, s * 0.60f);
        path.lineTo(s * 0.65f, s * 0.60f);
        path.close();
        fill.setColor(pressed ? 0xFFFF4444 : 0xFFFFFFFF);
        canvas.drawPath(path, fill);
        canvas.drawPath(path, stroke);
        canvas.restore();
    }
}
