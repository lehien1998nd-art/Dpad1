package com.dpadmouse.app;

import android.accessibilityservice.AccessibilityService;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Accessibility service: chặn phím D-pad, vẽ con trỏ lên trên mọi app,
 * và "click" vào control nằm dưới con trỏ.
 *
 * Phím (khi con trỏ đang BẬT):
 *   D-pad            : di chuyển con trỏ (giữ lâu = nhanh dần)
 *   D-pad giữa / A   : click
 *   X                : click giữ (long click)
 *   L1 / R1          : cuộn lên / xuống
 *   SELECT (đổi được): bật / tắt con trỏ
 */
public class CursorService extends AccessibilityService {

    /** MainActivity đặt true khi đang chờ người dùng nhấn phím để gán. */
    static volatile boolean captureMode = false;
    static volatile CursorService instance;

    private WindowManager wm;
    private CursorView cursorView;
    private WindowManager.LayoutParams lp;
    private SharedPreferences prefs;

    private boolean active = false;
    private int cx, cy;
    private int sw, sh;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        updateScreenSize();
        cx = sw / 2;
        cy = sh / 2;

        cursorView = new CursorView(this);
        int size = (int) (30 * getResources().getDisplayMetrics().density);
        lp = new WindowManager.LayoutParams(
                size, size,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        lp.x = cx - cursorView.pad;
        lp.y = cy - cursorView.pad;
        cursorView.setVisibility(View.GONE);
        wm.addView(cursorView, lp);
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        removeCursor();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        removeCursor();
        super.onDestroy();
    }

    private void removeCursor() {
        instance = null;
        removeJoyView();
        try {
            if (wm != null && cursorView != null) wm.removeView(cursorView);
        } catch (Exception ignored) {
        }
        cursorView = null;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override
    public void onInterrupt() { }

    // ------------------------------------------------------------------
    // Nhận phím
    // ------------------------------------------------------------------
    @Override
    protected boolean onKeyEvent(KeyEvent e) {
        if (captureMode || prefs == null || cursorView == null) return false;

        int code = e.getKeyCode();
        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;
        boolean first = down && e.getRepeatCount() == 0;

        if (code == prefs.getInt(Prefs.KEY_TOGGLE, Prefs.DEF_TOGGLE)) {
            if (first) setActive(!active);
            return true;
        }
        // Phím gán Home / Back / Recents: hoạt động cả khi con trỏ đang tắt
        if (handleGlobalKey(code, first)) return true;

        if (!active) return false;

        int clickKey = prefs.getInt(Prefs.KEY_CLICK, Prefs.DEF_CLICK);
        if (code == clickKey || code == KeyEvent.KEYCODE_BUTTON_A) {
            if (first) click(false);
            return true;
        }

        switch (code) {
            case KeyEvent.KEYCODE_DPAD_UP:
                if (down) move(0, -step(e));
                return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                if (down) move(0, step(e));
                return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                if (down) move(-step(e), 0);
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                if (down) move(step(e), 0);
                return true;
            case KeyEvent.KEYCODE_BUTTON_X:
                if (first) click(true);
                return true;
            case KeyEvent.KEYCODE_BUTTON_L1:
                if (first) scroll(false);
                return true;
            case KeyEvent.KEYCODE_BUTTON_R1:
                if (first) scroll(true);
                return true;
            default:
                // Khi cửa sổ joystick đang giữ focus, Back/B sẽ không tới app nên tự gửi Back
                if (joyView != null
                        && (code == KeyEvent.KEYCODE_BACK || code == KeyEvent.KEYCODE_BUTTON_B)) {
                    if (first) performGlobalAction(GLOBAL_ACTION_BACK);
                    return true;
                }
                return false; // Home... đi qua bình thường
        }
    }

    // ------------------------------------------------------------------
    // Joystick analog: cần cửa sổ có focus mới nhận được sự kiện joystick
    // ------------------------------------------------------------------
    private final Handler handler = new Handler(Looper.getMainLooper());
    private View joyView;
    private boolean joyRunning = false;
    private volatile float joyX, joyY;
    private float subX, subY;

    private void addJoyView() {
        if (joyView != null) return;
        joyView = new View(this);
        joyView.setOnGenericMotionListener(new View.OnGenericMotionListener() {
            @Override
            public boolean onGenericMotion(View v, MotionEvent e) {
                return handleJoystick(e);
            }
        });
        WindowManager.LayoutParams jp = new WindowManager.LayoutParams(
                1, 1,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT); // không có FLAG_NOT_FOCUSABLE => nhận focus
        jp.gravity = Gravity.TOP | Gravity.LEFT;
        try {
            wm.addView(joyView, jp);
        } catch (Exception ex) {
            joyView = null;
        }
    }

    private void removeJoyView() {
        joyX = 0;
        joyY = 0;
        if (joyView == null) return;
        try {
            wm.removeView(joyView);
        } catch (Exception ignored) {
        }
        joyView = null;
    }

    private boolean handleJoystick(MotionEvent e) {
        if ((e.getSource() & InputDevice.SOURCE_CLASS_JOYSTICK) == 0) return false;
        if (e.getAction() != MotionEvent.ACTION_MOVE) return false;
        joyX = e.getAxisValue(MotionEvent.AXIS_X);
        joyY = e.getAxisValue(MotionEvent.AXIS_Y);
        if (!joyRunning) {
            joyRunning = true;
            handler.post(joyTick);
        }
        return true;
    }

    private final Runnable joyTick = new Runnable() {
        @Override
        public void run() {
            if (!active || cursorView == null) {
                joyRunning = false;
                return;
            }
            float mx = shape(joyX);
            float my = shape(joyY);
            if (mx == 0f && my == 0f) {
                joyRunning = false;
                subX = 0;
                subY = 0;
                return;
            }
            float max = prefs.getInt(Prefs.SPEED, Prefs.DEF_SPEED) * 0.9f; // px mỗi 16ms
            subX += mx * max;
            subY += my * max;
            int dx = (int) subX;
            int dy = (int) subY;
            subX -= dx;
            subY -= dy;
            if (dx != 0 || dy != 0) move(dx, dy);
            handler.postDelayed(this, 16);
        }
    };

    /** Vùng chết 18% + đường cong bậc hai: nghiêng nhẹ = chậm, nghiêng hết = nhanh. */
    private static float shape(float a) {
        float dead = 0.18f;
        float m = Math.abs(a);
        if (m < dead) return 0f;
        float v = (m - dead) / (1f - dead);
        v = v * v;
        return a < 0 ? -v : v;
    }

    private boolean handleGlobalKey(int code, boolean first) {
        if (code == prefs.getInt(Prefs.KEY_SWIPE_UP, Prefs.UNSET)) {
            if (first) swipeFeed(true);
            return true;
        }
        if (code == prefs.getInt(Prefs.KEY_SWIPE_DOWN, Prefs.UNSET)) {
            if (first) swipeFeed(false);
            return true;
        }
        int action;
        if (code == prefs.getInt(Prefs.KEY_HOME, Prefs.UNSET)) {
            action = GLOBAL_ACTION_HOME;
        } else if (code == prefs.getInt(Prefs.KEY_BACK, Prefs.UNSET)) {
            action = GLOBAL_ACTION_BACK;
        } else if (code == prefs.getInt(Prefs.KEY_RECENTS, Prefs.UNSET)) {
            action = GLOBAL_ACTION_RECENTS;
        } else {
            return false;
        }
        if (first) performGlobalAction(action);
        return true; // nuốt cả sự kiện nhả phím
    }

    private int step(KeyEvent e) {
        int speed = prefs.getInt(Prefs.SPEED, Prefs.DEF_SPEED);
        float accel = 1f + Math.min(e.getRepeatCount(), 30) / 6f; // tối đa ~6 lần
        return Math.max(1, Math.round(speed * accel));
    }

    private void setActive(boolean on) {
        active = on;
        if (on) {
            updateScreenSize();
            cx = clamp(cx, 0, sw - 1);
            cy = clamp(cy, 0, sh - 1);
            applyPosition();
        }
        cursorView.setVisibility(on ? View.VISIBLE : View.GONE);
        if (on && prefs.getBoolean(Prefs.JOY, false)) {
            addJoyView();
        } else {
            removeJoyView();
        }
        Toast.makeText(this, on ? "Con trỏ: BẬT" : "Con trỏ: TẮT", Toast.LENGTH_SHORT).show();
    }

    private void move(int dx, int dy) {
        updateScreenSize();
        cx = clamp(cx + dx, 0, sw - 1);
        cy = clamp(cy + dy, 0, sh - 1);
        applyPosition();
    }

    private void applyPosition() {
        lp.x = cx - cursorView.pad;
        lp.y = cy - cursorView.pad;
        wm.updateViewLayout(cursorView, lp);
    }

    private void updateScreenSize() {
        Point p = new Point();
        wm.getDefaultDisplay().getRealSize(p);
        sw = p.x;
        sh = p.y;
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    // ------------------------------------------------------------------
    // Click / cuộn
    // ------------------------------------------------------------------
    private boolean rootMode() {
        return prefs.getBoolean(Prefs.ROOT, false);
    }

    private void click(boolean longClick) {
        cursorView.flash();

        if (rootMode()) {
            if (longClick) {
                shell("input swipe " + cx + " " + cy + " " + cx + " " + cy + " 800");
            } else {
                shell("input tap " + cx + " " + cy);
            }
            return;
        }

        int action = longClick
                ? AccessibilityNodeInfo.ACTION_LONG_CLICK
                : AccessibilityNodeInfo.ACTION_CLICK;

        // 1) Node ngay dưới con trỏ, hoặc cha của nó, được khai báo là bấm được
        AccessibilityNodeInfo n = nodeAt(cx, cy);
        for (AccessibilityNodeInfo p = n; p != null; p = p.getParent()) {
            boolean ok = longClick ? p.isLongClickable() : p.isClickable();
            if (ok && p.performAction(action)) return;
        }

        // 2) Thử bấm thẳng vào node và các cha dù không khai báo clickable
        for (AccessibilityNodeInfo p = n; p != null; p = p.getParent()) {
            if (p.performAction(action)) return;
        }

        // 3) Tìm nút bấm được GẦN NHẤT quanh con trỏ (trong ~24dp)
        AccessibilityNodeInfo root = rootAt(cx, cy);
        if (root != null) {
            int maxDist = (int) (24 * getResources().getDisplayMetrics().density);
            AccessibilityNodeInfo[] best = new AccessibilityNodeInfo[1];
            long[] bestKey = new long[]{Long.MAX_VALUE, Long.MAX_VALUE};
            scan(root, cx, cy, longClick, maxDist, best, bestKey);
            if (best[0] != null && best[0].performAction(action)) return;
        }

        Toast.makeText(this,
                "Không tìm thấy nút để bấm (game/màn hình tự vẽ cần root)",
                Toast.LENGTH_SHORT).show();
    }

    /** Duyệt cây node, chọn node bấm được gần điểm (x, y) nhất (rồi đến nhỏ nhất). */
    private void scan(AccessibilityNodeInfo n, int x, int y, boolean lng, int maxDist,
                      AccessibilityNodeInfo[] best, long[] bestKey) {
        if (n == null || !n.isVisibleToUser()) return;
        for (int i = 0; i < n.getChildCount(); i++) {
            scan(n.getChild(i), x, y, lng, maxDist, best, bestKey);
        }
        boolean ok = lng ? n.isLongClickable() : n.isClickable();
        if (!ok) return;
        Rect r = new Rect();
        n.getBoundsInScreen(r);
        if (r.width() <= 0 || r.height() <= 0) return;
        int dx = Math.max(Math.max(r.left - x, 0), x - r.right);
        int dy = Math.max(Math.max(r.top - y, 0), y - r.bottom);
        long d2 = (long) dx * dx + (long) dy * dy;
        if (d2 > (long) maxDist * maxDist) return;
        long area = (long) r.width() * r.height();
        if (d2 < bestKey[0] || (d2 == bestKey[0] && area < bestKey[1])) {
            bestKey[0] = d2;
            bestKey[1] = area;
            best[0] = n;
        }
    }

    private void scroll(boolean forward) {
        if (rootMode()) {
            int d = sh / 3;
            int y2 = forward ? cy - d : cy + d;
            shell("input swipe " + cx + " " + cy + " " + cx + " " + clamp(y2, 0, sh - 1) + " 300");
            return;
        }
        AccessibilityNodeInfo n = nodeAt(cx, cy);
        for (AccessibilityNodeInfo p = n; p != null; p = p.getParent()) {
            if (p.isScrollable()) {
                p.performAction(forward
                        ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                        : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
                return;
            }
        }
        swipeFeed(forward); // không có gì dưới con trỏ: cuộn vùng cuộn lớn nhất
    }

    /**
     * Vuốt lên (next=true) = video/mục kế tiếp, vuốt xuống = mục trước.
     * Không cần con trỏ. Root: giả lập vuốt thật; không root: cuộn vùng cuộn lớn nhất.
     */
    private void swipeFeed(boolean next) {
        updateScreenSize();
        if (rootMode()) {
            int x = sw / 2;
            int yHi = (int) (sh * 0.75f);
            int yLo = (int) (sh * 0.25f);
            shell("input swipe " + x + " " + (next ? yHi : yLo)
                    + " " + x + " " + (next ? yLo : yHi) + " 150");
            return;
        }
        AccessibilityNodeInfo root = rootAt(sw / 2, sh / 2);
        AccessibilityNodeInfo target = root == null ? null : largestScrollable(root);
        if (target != null && target.performAction(next
                ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)) {
            return;
        }
        Toast.makeText(this, "Không tìm thấy vùng cuộn (cần root để vuốt thật)",
                Toast.LENGTH_SHORT).show();
    }

    private AccessibilityNodeInfo largestScrollable(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo best = null;
        long bestArea = -1;
        Rect r = new Rect();
        List<AccessibilityNodeInfo> stack = new ArrayList<AccessibilityNodeInfo>();
        stack.add(n);
        while (!stack.isEmpty()) {
            AccessibilityNodeInfo c = stack.remove(stack.size() - 1);
            if (c == null || !c.isVisibleToUser()) continue;
            if (c.isScrollable()) {
                c.getBoundsInScreen(r);
                long area = (long) r.width() * r.height();
                if (area > bestArea) {
                    bestArea = area;
                    best = c;
                }
            }
            for (int i = 0; i < c.getChildCount(); i++) stack.add(c.getChild(i));
        }
        return best;
    }

    /** Node sâu nhất, đang hiển thị, chứa điểm (x, y) — ở cửa sổ trên cùng. */
    private AccessibilityNodeInfo nodeAt(int x, int y) {
        List<AccessibilityWindowInfo> ws = getWindows();
        if (ws != null && !ws.isEmpty()) {
            List<AccessibilityWindowInfo> sorted = new ArrayList<AccessibilityWindowInfo>(ws);
            Collections.sort(sorted, new Comparator<AccessibilityWindowInfo>() {
                @Override
                public int compare(AccessibilityWindowInfo a, AccessibilityWindowInfo b) {
                    return b.getLayer() - a.getLayer(); // layer cao (trên cùng) trước
                }
            });
            for (AccessibilityWindowInfo w : sorted) {
                if (w.getType() == AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY) continue;
                Rect wr = new Rect();
                w.getBoundsInScreen(wr);
                if (!wr.contains(x, y)) continue;
                AccessibilityNodeInfo root = w.getRoot();
                if (root == null) continue;
                AccessibilityNodeInfo n = deepest(root, x, y);
                if (n != null) return n;
            }
        }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        return root == null ? null : deepest(root, x, y);
    }

    /** Root của cửa sổ trên cùng chứa điểm (x, y). */
    private AccessibilityNodeInfo rootAt(int x, int y) {
        List<AccessibilityWindowInfo> ws = getWindows();
        if (ws != null && !ws.isEmpty()) {
            List<AccessibilityWindowInfo> sorted = new ArrayList<AccessibilityWindowInfo>(ws);
            Collections.sort(sorted, new Comparator<AccessibilityWindowInfo>() {
                @Override
                public int compare(AccessibilityWindowInfo a, AccessibilityWindowInfo b) {
                    return b.getLayer() - a.getLayer();
                }
            });
            for (AccessibilityWindowInfo w : sorted) {
                if (w.getType() == AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY) continue;
                Rect wr = new Rect();
                w.getBoundsInScreen(wr);
                if (!wr.contains(x, y)) continue;
                AccessibilityNodeInfo root = w.getRoot();
                if (root != null) return root;
            }
        }
        return getRootInActiveWindow();
    }

    private AccessibilityNodeInfo deepest(AccessibilityNodeInfo n, int x, int y) {
        Rect r = new Rect();
        n.getBoundsInScreen(r);
        if (!r.contains(x, y)) return null;
        for (int i = n.getChildCount() - 1; i >= 0; i--) {
            AccessibilityNodeInfo c = n.getChild(i);
            if (c == null || !c.isVisibleToUser()) continue;
            AccessibilityNodeInfo d = deepest(c, x, y);
            if (d != null) return d;
        }
        return n;
    }

    // ------------------------------------------------------------------
    // Chế độ root: dùng lệnh "input" (chạy được cả trong game)
    // ------------------------------------------------------------------
    private void shell(final String cmd) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", cmd});
                    p.waitFor();
                } catch (Exception ignored) {
                }
            }
        }).start();
    }
}
